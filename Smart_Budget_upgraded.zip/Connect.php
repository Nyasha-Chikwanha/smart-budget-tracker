<?php
// Connect.php - central DB connection
$DB_SERVER = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'smart_budget';

function db_connect() {
    global $DB_SERVER, $DB_USER, $DB_PASS, $DB_NAME;
    $conn = new mysqli($DB_SERVER, $DB_USER, $DB_PASS, $DB_NAME);
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(['success'=>false, 'message'=>'Database connection failed: '.$conn->connect_error]);
        exit();
    }
    // Set charset
    $conn->set_charset('utf8mb4');
    return $conn;
}
?>