NOTICE:
- I updated the backend to use database name 'smart_budget'.
- Connect.php contains DB credentials (default XAMPP: root, no password).
- API endpoints:
   - /Api.php (legacy) accepts JSON POST with action 'signup' or 'update'.
   - /api/signup (pretty URL) -> api/signup.php
   - /api/update (pretty URL) -> api/update.php
- Ensure the database 'smart_budget' exists and import the provided SQL file in the project if not already done.
