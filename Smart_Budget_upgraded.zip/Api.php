<?php
header('Content-Type: application/json');
require_once __DIR__ . '/Connect.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if ($method !== 'POST') {
    echo json_encode(['success'=>false, 'message'=>'Only POST allowed.']);
    exit();
}

$action = $input['action'] ?? 'signup';

if ($action === 'signup') {
    $fullname = trim($input['fullname'] ?? '');
    $email = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';

    if (!$fullname || !$email || !$password) {
        echo json_encode(['success'=>false, 'message'=>'Missing required fields.']);
        exit();
    }

    $conn = db_connect();

    // check if email exists
    $stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        echo json_encode(['success'=>false, 'message'=>'Email already registered.']);
        $stmt->close();
        $conn->close();
        exit();
    }
    $stmt->close();

    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $now = date('Y-m-d H:i:s');

    $stmt = $conn->prepare('INSERT INTO users (fullname, email, password, created_at, updated_at) VALUES (?, ?, ?, ?, ?)');
    $stmt->bind_param('sssss', $fullname, $email, $hashed, $now, $now);
    if ($stmt->execute()) {
        echo json_encode(['success'=>true, 'id'=>$stmt->insert_id]);
    } else {
        echo json_encode(['success'=>false, 'message'=>'Error saving data.']);
    }
    $stmt->close();
    $conn->close();
    exit();
}

if ($action === 'update') {
    $id = intval($input['id'] ?? 0);
    if (!$id) { echo json_encode(['success'=>false,'message'=>'Missing user id']); exit(); }

    $fields = [];
    $params = [];
    $types = '';
    if (!empty($input['fullname'])) { $fields[] = 'fullname = ?'; $params[] = $input['fullname']; $types .= 's'; }
    if (!empty($input['email'])) { $fields[] = 'email = ?'; $params[] = $input['email']; $types .= 's'; }
    if (!empty($input['password'])) { $fields[] = 'password = ?'; $params[] = password_hash($input['password'], PASSWORD_DEFAULT); $types .= 's'; }
    if (!empty($input['phone'])) { $fields[] = 'phone = ?'; $params[] = $input['phone']; $types .= 's'; }
    if (!empty($input['address'])) { $fields[] = 'address = ?'; $params[] = $input['address']; $types .= 's'; }

    if (empty($fields)) { echo json_encode(['success'=>false,'message'=>'No fields to update']); exit(); }

    $fields[] = 'updated_at = ?';
    $params[] = date('Y-m-d H:i:s');
    $types .= 's';

    $conn = db_connect();
    $sql = 'UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?';
    $params[] = $id;
    $types .= 'i';

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    if ($stmt->execute()) {
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['success'=>false, 'message'=>'Update failed.']);
    }
    $stmt->close();
    $conn->close();
    exit();
}

echo json_encode(['success'=>false, 'message'=>'Unknown action.']);
?>