<?php
// api/update.php - accepts JSON POST {id, fullname?, email?, password?, phone?, address?}
header('Content-Type: application/json');
require_once __DIR__ . '/../Connect.php';
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$input['action'] = 'update';
require_once __DIR__ . '/../Api.php';
?>