<?php
// api/signup.php - accepts JSON POST {fullname,email,password}
header('Content-Type: application/json');
require_once __DIR__ . '/../Connect.php';
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$input['action'] = 'signup';
require_once __DIR__ . '/../Api.php';
?>